package com.example.covid_19_app.dataclasses

class WorldcaseDataclass {

    var Header:String=""
    var value:String=""
    var colour:String=""

    constructor(H:String,v:String,c:String)
    {


        this.Header=H
        this.value=v
        this.colour=c

    }
    constructor()
    {

    }
}