# COVID19APP
get the latest information related to COVID-19 
This App use API to get data from API Website
# https://corona.lmao.ninja/v2/all





